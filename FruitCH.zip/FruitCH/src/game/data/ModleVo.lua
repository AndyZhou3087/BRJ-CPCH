--角色皮肤数据
local ModleVo = 
{
    roleId = 0, --角色模型id
    isOwn = false,  --是否已经拥有
    roleLv = 0, --角色当前等级
}
return ModleVo