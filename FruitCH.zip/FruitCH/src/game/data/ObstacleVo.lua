--[[
障碍数据
]]
local ObstacleVo = 
    {
        m_id = 0, --障碍id
        m_type = 0,   --障碍类型
        m_time = 0,   --障碍技能，false表示无
        m_att = 0,  --障碍攻击力
    }

return ObstacleVo