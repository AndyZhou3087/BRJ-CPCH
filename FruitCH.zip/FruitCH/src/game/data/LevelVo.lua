--关卡数据

local LevelVo={
    id = 0, --关卡id
    star = 0,--当前星级
    score = 0,--关卡得分
    isPass = false,--是否过关
}

return LevelVo
