--[[
物品数据
]]
local GoodsVo = 
{
    id = 0, --物品id
    num = 0,--物品数量
}

return GoodsVo