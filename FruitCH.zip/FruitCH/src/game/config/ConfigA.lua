ConfigA = {}

ConfigA[1] = {
    _id= 1,
    map = 1,
--    obstacle=13,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
--    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
--    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[2] = {
    _id= 2,
    obstacle=2,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[3] = {
    _id= 3,
    obstacle=14,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[4] = {
    _id= 4,
    obstacle=15,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[5] = {
    _id= 5,
    obstacle=5,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[6] = {
    _id= 6,
    obstacle=7,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[7] = {
    _id= 7,
    obstacle=8,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 100,    --权重
}
ConfigA[8] = {
    _id= 8,
    obstacle=19,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigA[9] = {
    _id= 9,
    obstacle=41,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[10] = {
    _id= 10,
    obstacle=43,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[11] = {
    _id= 11,
    obstacle=40,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[12] = {
    _id= 12,
    obstacle=71,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[13] = {
    _id= 13,
    obstacle=72,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[14] = {
    _id= 14,
    obstacle=73,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[15] = {
    _id= 15,
    obstacle=74,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[16] = {
    _id= 16,
    obstacle=75,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[17] = {
    _id= 17,
    obstacle=76,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[18] = {
    _id= 18,
    obstacle=77,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[19] = {
    _id= 19,
    obstacle=78,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[20] = {
    _id= 20,
    obstacle=79,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 80,    --权重
}
ConfigA[21] = {
    _id= 21,
    obstacle=80,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[22] = {
    _id= 22,
    obstacle=81,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[23] = {
    _id= 23,
    obstacle=82,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[24] = {
    _id= 24,
    obstacle=83,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[25] = {
    _id= 25,
    obstacle=84,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[26] = {
    _id= 26,
    obstacle=85,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[27] = {
    _id= 27,
    obstacle=86,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[28] = {
    _id= 28,
    obstacle=87,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[29] = {
    _id= 29,
    obstacle=88,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[30] = {
    _id= 30,
    obstacle=89,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 50,    --权重
}
ConfigA[31] = {
    _id= 31,
    obstacle=0,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 5,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 700,    --权重
}
ConfigA[32] = {
    _id= 32,
    obstacle=0,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 6,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 800,    --权重
}