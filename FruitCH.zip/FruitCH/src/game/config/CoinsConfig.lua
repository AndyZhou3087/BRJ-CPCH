--[[
金币配置
]]

Coin_Type=
    {
        Coin_Gold = 1,
        Coin_Silver = 2,
        Coin_Copper = 3,
    }