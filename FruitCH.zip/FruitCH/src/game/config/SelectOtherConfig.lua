--[[
关卡场景花草配置
]]

--Y范围[0,440]
--X范围[0,...]

SelectOtherConfig=
{
        {res="Select/Select_1.png",x=0,y=0,},--(第一个坐标必须为(0,0))
        {res="Select/Select_1.png",x=128,y=435,},
        {res="Select/Select_2.png",x=220,y=134,},
        {res="Select/Select_3.png",x=350,y=65,},
        {res="Select/Select_4.png",x=450,y=300,},
        {res="Select/Select_5.png",x=740,y=85,},
        {res="Select/Select_6.png",x=965,y=388,},
        {res="Select/Select_1.png",x=790,y=300,},
        {res="Select/Select_7.png",x=1165,y=20,},
        {res="Select/Select_10.png",x=1325,y=228,},
        {res="Select/Select_11.png",x=1635,y=390,},
        {res="Select/Select_9.png",x=1545,y=95,},
        {res="Select/Select_12.png",x=1865,y=105,},
        {res="Select/Select_8.png",x=2031,y=340,},
        {res="Select/Select_10.png",x=2165,y=20,},
        {res="Select/Select_6.png",x=2765,y=20,},

        {res="Select/Select_1.png",x=2880,y=460,},--(Y坐标必须有一个为440)
}
