ConfigC = {}

ConfigC[1] = {
    _id= 1,
    obstacle=13,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[2] = {
    _id= 2,
    obstacle=2,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[3] = {
    _id= 3,
    obstacle=14,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[4] = {
    _id= 4,
    obstacle=15,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[5] = {
    _id= 5,
    obstacle=5,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[6] = {
    _id= 6,
    obstacle=7,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[7] = {
    _id= 7,
    obstacle=8,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[8] = {
    _id= 8,
    obstacle=19,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 60,    --权重
}
ConfigC[9] = {
    _id= 9,
    obstacle=41,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[10] = {
    _id= 10,
    obstacle=43,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[11] = {
    _id= 11,
    obstacle=40,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[12] = {
    _id= 12,
    obstacle=44,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[13] = {
    _id= 13,
    obstacle=45,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[14] = {
    _id= 14,
    obstacle=46,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[15] = {
    _id= 15,
    obstacle=47,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[16] = {
    _id= 16,
    obstacle=48,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[17] = {
    _id= 17,
    obstacle=49,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[18] = {
    _id= 18,
    obstacle=50,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[19] = {
    _id= 19,
    obstacle=51,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[20] = {
    _id= 20,
    obstacle=52,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[21] = {
    _id= 21,
    obstacle=90,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 200,    --权重
}
ConfigC[22] = {
    _id= 22,
    obstacle=0,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 3,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 10,    --每组之间的间隔差距，单位:像素
    probability = 300,    --权重
}
ConfigC[23] = {
    _id= 23,
    obstacle=0,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 4,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 600,    --权重
}
ConfigB[24] = {
    _id= 24,
    obstacle=30,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 400,    --权重
}
ConfigB[25] = {
    _id= 25,
    obstacle=31,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 300,    --权重
}
ConfigB[26] = {
    _id= 26,
    obstacle=32,   --障碍物，此id对应ObsGroupConfig中配置文件，填0表示无障碍
    coins = 0,    --金币, 此id对应CoinsConfig配置文件，填0表示无
    goods=0,      --道具  此id对应GoodGroupConfig配置文件,填0表示无道具
    gap = 500,    --每组之间的间隔差距，单位:像素
    probability = 300,    --权重
}