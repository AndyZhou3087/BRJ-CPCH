--无尽模式配置

EndlessMode={
    costPower=1,  --消耗体力
    goods={1,2,3,4}, --开局道具
    speed = 32,   --初始速度
    --难易度距离分隔
DistanceD={
    move = 0,--单位:米(按照像素换算公式)
    isClip = true,
    speed = 32,
},
DistanceC={
    move = 30,
    isClip = false,
        speed = 320,
},
DistanceB={
    move = 2000,
    isClip = false,
        speed = 32,
},
DistanceA={
    move = 10000,
    isClip = false,
        speed = 32,
},
DistanceS={
    move = 20000,
    isClip = false,
        speed = 32,
},
}